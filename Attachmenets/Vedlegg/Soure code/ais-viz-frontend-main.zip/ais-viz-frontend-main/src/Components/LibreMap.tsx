import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import type { Point } from "geojson";
import type { FeatureCollection } from "geojson";
import { MapContainer } from "./MapContainer";
import type { ShipInfoProps } from "./ShipInfo/ShipInfo";
import type Supercluster from "supercluster";

//import { Layer } from "react-map-gl/mapbox";
import { useMemo } from "react";

// Used to allow MapControls to use the values

/* 
Function component that creates a libremap instance from libremap open source project, is not finished as not going to have style inside
code outside of useffect and useref is from mapLibre.
*/

interface LibreMapProps {
  responseData: FeatureCollection<Point>;
  shipInfoContextValue: {
    shipInfoProps: ShipInfoProps | undefined;
    setShipInfoProps: React.Dispatch<
      React.SetStateAction<ShipInfoProps | undefined>
    >;
  };
  cluster?: Supercluster;
  baseStations: FeatureCollection<Point>;
}

/*
exports a libremap sending down props to mapcontainer that is responsible for creating map and maintaining it. 
*/
export const LibreMap = ({
  responseData,
  shipInfoContextValue,
  baseStations,
}: LibreMapProps) => {
  return (
    <>
      <MapContainer
        responseData={responseData}
        shipInfoContextValue={shipInfoContextValue}
        baseStations={baseStations}
      />
    </>
  );
};
